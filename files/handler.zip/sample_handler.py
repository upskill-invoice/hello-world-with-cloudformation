def lambda_handler(event, context):
    d = {}
    d["id"] = 30
    d["name"] = "Janek"
    s = json.dumps(d)
    return {
		'headers': {
            'content-type': 'application/json'
        },
		"statusCode": 200,
		"body": json.dumps(d)
	}
