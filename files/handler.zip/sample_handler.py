import json

def lambda_handler(event, context):
    obj = {}
    obj["id"] = 1
    obj["first_name"] = "Jan"
    obj["second_name"] = "Kowalski"
    return {
		'headers': {
            'content-type': 'application/json'
        },
		"statusCode": 200,
		"body": json.dumps(obj)
	}
